-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 05 maj 2023 kl 12:42
-- Serverversion: 10.4.27-MariaDB
-- PHP-version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `forum`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `comments`
--

CREATE TABLE `comments` (
  `id` int(30) NOT NULL,
  `comment` text NOT NULL,
  `user` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `replyTo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumpning av Data i tabell `comments`
--

INSERT INTO `comments` (`id`, `comment`, `user`, `date`, `replyTo`) VALUES
(89, 'Jag hetter $user\r\n', 'admin', '2023-05-05 12:31:17', ''),
(90, 'jag heter echo $user\r\n', 'admin', '2023-05-05 12:31:30', ''),
(91, 'sdds\r\n', 'admin', '2023-05-05 12:34:58', ''),
(92, 'hej', 'admin', '2023-05-05 12:42:12', '');

-- --------------------------------------------------------

--
-- Tabellstruktur `username`
--

CREATE TABLE `username` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumpning av Data i tabell `username`
--

INSERT INTO `username` (`username`, `password`, `email`) VALUES
('admin', '123', ''),
('Ahmad', 'allan0908', 'ahmadalikhan205@gmail.com'),
('Dashmir', '1233', '1223@gmail.com'),
('Tarek', '1234', 'tarek@gmail.com');

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `username`
--
ALTER TABLE `username`
  ADD PRIMARY KEY (`username`,`email`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
